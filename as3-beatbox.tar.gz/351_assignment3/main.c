// draft of what the main will look like



int main() {
    // start the playback buffer thread
    // start the beat generator thread
    // start polling module, this will end up display ur mode and lalalal
    // while quit is not true 
        // print stats every 1s
    // once quit is true
    // close all threads

}